package Game;

public class Manche {

    private Tour[] tour = new Tour[4];
}
